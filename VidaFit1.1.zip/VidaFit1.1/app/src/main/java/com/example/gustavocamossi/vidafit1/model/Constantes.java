package com.example.gustavocamossi.vidafit1.model;

public interface Constantes {

    String USUARIO_ADMIN = "gustavo.camossi@gmail.com";
}
